### 2.0.0: February 10th, 2016
* Rewrite plugin, require Composer

### 1.0.3: August 19th, 2014
* Only show menu item for administrators, add filter for visibility control

### 1.0.2: July 22nd, 2014
* Add support for sub-domain subsites in multisite

### 1.0.1: April 7th, 2014
* Directory indepenent, enable GitHub Updater

### 1.0.0: January 13th, 2014
* Initial release
